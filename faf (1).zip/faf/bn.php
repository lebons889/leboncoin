<?php
session_start();
include_once './inc/app.php';


  header("Location: https://direct.lc.chat/18264072/");


?>